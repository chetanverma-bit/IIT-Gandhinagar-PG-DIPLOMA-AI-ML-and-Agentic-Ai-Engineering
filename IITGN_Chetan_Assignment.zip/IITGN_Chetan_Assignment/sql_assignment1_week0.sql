
-- Q1.
SELECT event_id, store_id, product_code, base_price, promo_type
FROM fact_events
WHERE base_price > 1000;
 
 
-- Q2. 
SELECT event_id, product_code, promo_type,
       `quantity_sold(before_promo)`,
       `quantity_sold(after_promo)`
FROM fact_events
WHERE `quantity_sold(after_promo)` > 100
ORDER BY `quantity_sold(after_promo)` DESC;
 
 
-- Q3. 
SELECT DISTINCT promo_type
FROM fact_events;
 
 
-- Q4. 
SELECT COUNT(*)                            AS total_events,
       SUM(`quantity_sold(before_promo)`)  AS total_before,
       SUM(`quantity_sold(after_promo)`)   AS total_after,
       AVG(base_price)                     AS avg_base_price,
       MAX(base_price)                     AS max_base_price,
       MIN(base_price)                     AS min_base_price
FROM fact_events;
 
 
-- Q5. 
SELECT promo_type,
       COUNT(*)                            AS event_count,
       SUM(`quantity_sold(before_promo)`)  AS total_before,
       SUM(`quantity_sold(after_promo)`)   AS total_after
FROM fact_events
GROUP BY promo_type
ORDER BY total_after DESC;
 
 
-- Q6. 
SELECT promo_type,
       SUM(`quantity_sold(before_promo)`) AS total_before,
       SUM(`quantity_sold(after_promo)`)  AS total_after,
       SUM(`quantity_sold(after_promo)`) - SUM(`quantity_sold(before_promo)`) AS quantity_change
FROM fact_events
GROUP BY promo_type
ORDER BY quantity_change DESC;
 
 
-- Q7. 
SELECT p.product_code, p.product_name, p.category,
       SUM(f.`quantity_sold(after_promo)`) AS total_quantity_after
FROM fact_events f
JOIN dim_products p ON f.product_code = p.product_code
GROUP BY p.product_code, p.product_name, p.category
ORDER BY total_quantity_after DESC;
 
 
-- Q8. 
SELECT p.category,
       COUNT(*)                              AS event_count,
       SUM(f.`quantity_sold(before_promo)`)  AS total_before,
       SUM(f.`quantity_sold(after_promo)`)   AS total_after,
       SUM(f.`quantity_sold(after_promo)`) - SUM(f.`quantity_sold(before_promo)`) AS quantity_change
FROM fact_events f
JOIN dim_products p ON f.product_code = p.product_code
GROUP BY p.category
ORDER BY total_after DESC;

 
-- Q9. 
SELECT s.city,
       COUNT(*)                              AS event_count,
       SUM(f.`quantity_sold(before_promo)`)  AS total_before,
       SUM(f.`quantity_sold(after_promo)`)   AS total_after
FROM fact_events f
JOIN dim_stores s ON f.store_id = s.store_id
GROUP BY s.city
ORDER BY total_after DESC;
 
 
-- Q10. 
SELECT c.campaign_name, c.start_date, c.end_date,
       COUNT(*)                              AS event_count,
       SUM(f.`quantity_sold(before_promo)`)  AS total_before,
       SUM(f.`quantity_sold(after_promo)`)   AS total_after
FROM fact_events f
JOIN dim_campaigns c ON f.campaign_id = c.campaign_id
GROUP BY c.campaign_id, c.campaign_name, c.start_date, c.end_date
ORDER BY total_after DESC;

 
-- Q11. 
SELECT p.category,
       SUM(f.`quantity_sold(after_promo)`) AS total_quantity_after,
       AVG(f.base_price)                   AS avg_base_price
FROM fact_events f
JOIN dim_products p ON f.product_code = p.product_code
GROUP BY p.category
HAVING SUM(f.`quantity_sold(after_promo)`) > 1000
ORDER BY total_quantity_after DESC;
 
 
-- Q12. 
SELECT s.city, p.category,
       SUM(f.`quantity_sold(after_promo)`) AS total_quantity_after
FROM fact_events f
JOIN dim_stores   s ON f.store_id = s.store_id
JOIN dim_products p ON f.product_code = p.product_code
GROUP BY s.city, p.category
ORDER BY s.city ASC, total_quantity_after DESC;
 
 
-- Q13. 
SELECT p.product_name, p.category,
       SUM(f.`quantity_sold(before_promo)`) AS total_before,
       SUM(f.`quantity_sold(after_promo)`)  AS total_after,
       SUM(f.`quantity_sold(after_promo)`) - SUM(f.`quantity_sold(before_promo)`) AS quantity_change,
       ROUND(
         (SUM(f.`quantity_sold(after_promo)`) - SUM(f.`quantity_sold(before_promo)`))
         / NULLIF(SUM(f.`quantity_sold(before_promo)`), 0) * 100, 2
       ) AS percentage_change
FROM fact_events f
JOIN dim_products p ON f.product_code = p.product_code
GROUP BY p.product_code, p.product_name, p.category
ORDER BY percentage_change DESC;
 
 
-- Q14.
SELECT c.campaign_name, f.promo_type,
       COUNT(*)                              AS event_count,
       SUM(f.`quantity_sold(before_promo)`)  AS total_before,
       SUM(f.`quantity_sold(after_promo)`)   AS total_after,
       SUM(f.`quantity_sold(after_promo)`) - SUM(f.`quantity_sold(before_promo)`) AS quantity_change
FROM fact_events f
JOIN dim_campaigns c ON f.campaign_id = c.campaign_id
GROUP BY c.campaign_name, f.promo_type
ORDER BY c.campaign_name ASC, quantity_change DESC;
 
 
-- Q15. 
SELECT p.product_name, p.category,
       SUM(f.base_price * f.`quantity_sold(before_promo)`) AS revenue_before,
       SUM(f.base_price * f.`quantity_sold(after_promo)`)  AS revenue_after,
       SUM(f.base_price * f.`quantity_sold(after_promo)`)
         - SUM(f.base_price * f.`quantity_sold(before_promo)`) AS revenue_difference
FROM fact_events f
JOIN dim_products p ON f.product_code = p.product_code
GROUP BY p.product_code, p.product_name, p.category
ORDER BY revenue_difference DESC;
 
 
-- Q16. 
WITH promo AS (
    SELECT promo_type,
           SUM(`quantity_sold(before_promo)`) AS total_before,
           SUM(`quantity_sold(after_promo)`)  AS total_after
    FROM fact_events
    GROUP BY promo_type
)
SELECT promo_type, total_before, total_after,
       ROUND((total_after - total_before) / NULLIF(total_before, 0) * 100, 2) AS percentage_change,
       CASE
           WHEN (total_after - total_before) / NULLIF(total_before, 0) * 100 >= 50 THEN 'High Impact'
           WHEN (total_after - total_before) / NULLIF(total_before, 0) * 100 >= 20 THEN 'Medium Impact'
           ELSE 'Low Impact'
       END AS performance_category
FROM promo
ORDER BY percentage_change DESC;

 
-- Q17. 
WITH product_totals AS (
    SELECT p.category, p.product_name,
           SUM(f.`quantity_sold(after_promo)`) AS total_quantity_after
    FROM fact_events f
    JOIN dim_products p ON f.product_code = p.product_code
    GROUP BY p.category, p.product_code, p.product_name
),
ranked AS (
    SELECT category, product_name, total_quantity_after,
           DENSE_RANK() OVER (PARTITION BY category ORDER BY total_quantity_after DESC) AS category_rank
    FROM product_totals
)
SELECT category, product_name, total_quantity_after, category_rank
FROM ranked
WHERE category_rank <= 2
ORDER BY category, category_rank;

 
-- Q18. 
WITH store_totals AS (
    SELECT s.city, s.store_id,
           SUM(f.`quantity_sold(after_promo)`) AS total_quantity_after
    FROM fact_events f
    JOIN dim_stores s ON f.store_id = s.store_id
    GROUP BY s.city, s.store_id
),
ranked AS (
    SELECT city, store_id, total_quantity_after,
           DENSE_RANK() OVER (PARTITION BY city ORDER BY total_quantity_after DESC) AS city_rank
    FROM store_totals
)
SELECT city, store_id, total_quantity_after, city_rank
FROM ranked
WHERE city_rank <= 2
ORDER BY city, city_rank;
 
 
-- Q19.
WITH campaign_product AS (
    SELECT c.campaign_name, p.product_name,
           SUM(f.`quantity_sold(before_promo)`) AS total_before,
           SUM(f.`quantity_sold(after_promo)`)  AS total_after,
           SUM(f.`quantity_sold(after_promo)`) - SUM(f.`quantity_sold(before_promo)`) AS quantity_change,
           ROUND(
             (SUM(f.`quantity_sold(after_promo)`) - SUM(f.`quantity_sold(before_promo)`))
             / NULLIF(SUM(f.`quantity_sold(before_promo)`), 0) * 100, 2
           ) AS percentage_change
    FROM fact_events f
    JOIN dim_campaigns c ON f.campaign_id = c.campaign_id
    JOIN dim_products  p ON f.product_code = p.product_code
    GROUP BY c.campaign_id, c.campaign_name, p.product_code, p.product_name
),
ranked AS (
    SELECT *,
           DENSE_RANK() OVER (
               PARTITION BY campaign_name
               ORDER BY percentage_change DESC
           ) AS campaign_rank
    FROM campaign_product
    WHERE percentage_change IS NOT NULL   
)
SELECT campaign_name, product_name, total_before, total_after,
       quantity_change, percentage_change, campaign_rank
FROM ranked
WHERE campaign_rank <= 3
ORDER BY campaign_name, campaign_rank;
 
-- Q20. 
WITH product_metrics AS (
    SELECT p.product_code, p.product_name, p.category,
           COUNT(*)                                             AS event_count,
           SUM(f.`quantity_sold(before_promo)`)                 AS total_before,
           SUM(f.`quantity_sold(after_promo)`)                  AS total_after,
           SUM(f.`quantity_sold(after_promo)`) - SUM(f.`quantity_sold(before_promo)`) AS quantity_change,
           ROUND(
             (SUM(f.`quantity_sold(after_promo)`) - SUM(f.`quantity_sold(before_promo)`))
             / NULLIF(SUM(f.`quantity_sold(before_promo)`), 0) * 100, 2
           )                                                    AS percentage_change,
           SUM(f.base_price * f.`quantity_sold(before_promo)`)  AS revenue_before,
           SUM(f.base_price * f.`quantity_sold(after_promo)`)   AS revenue_after,
           SUM(f.base_price * f.`quantity_sold(after_promo)`)
             - SUM(f.base_price * f.`quantity_sold(before_promo)`) AS revenue_change,
           ROUND(AVG(f.base_price), 2)                          AS avg_base_price
    FROM fact_events f
    JOIN dim_products p ON f.product_code = p.product_code
    GROUP BY p.product_code, p.product_name, p.category
),
ranked AS (
    SELECT *,
           DENSE_RANK() OVER (PARTITION BY category ORDER BY revenue_change DESC) AS category_rank
    FROM product_metrics
)
SELECT product_name, category, event_count, total_before, total_after,
       quantity_change, percentage_change, revenue_before, revenue_after,
       revenue_change, avg_base_price, category_rank
FROM ranked
WHERE category_rank <= 2
ORDER BY category, category_rank;
 